$("#loginButton").click(function(){
    var Password1 = $("#pass1").val();
    var Password2 = $("#pass2").val();


    if(Password1!="" && Password2!=""){ 
          if(Password1==Password2 ) 
        {alert("successfuly login")}

        else{alert("password is not missing")}
    
    }else
    {alert("plese enter password")}


})

$(".ali").click(function(){
    $("ul li:first-child").hide()

});